README : 

// Auteur : Djebien Tarik
// Date   : decembre 2009
// Objet  : Les Grands Entiers

Ci-Joint le projet 

Arborescence de l'archive Tarik_Djebien_MIMP32.tar.gz :
    |
    |_____README
    |
    |_____gdEntier.pdf
    |
    |_____Les_Grands_Entiers/
           |
           |
           |__Unité/ U_Element.pas U_Liste.pas U_Grands_Entiers.pas
           |                     
           |__test/ ecrireGDEntier.pas Factorielle100.pas lireGDEntier.pas Operateurs.pas string2GDEntier.pas tailleGDEntier.pas
           |                     
           |                     
           |__Questions/ Question[1-1suite-2].jpg questions.txt 
          

Pour les commentaires :

tarik.djebien@etudiant.univ-lille1.fr

Cordialement.
