README : 

// Auteur : Djebien Tarik
// Date   : decembre 2009
// Objet  : Les Arbres binaires

Ci-Joint le TP numero 9

Arborescence de l'archive Tarik_Djebien_MIMP32.tar.gz :
    |
    |_____README
    |
    |_____tp-arbres.pdf
    |
    |_____Tp-Arbres/
           |
           |
           |__U_Arbre/ U_Arbre.pas
           |                     
           |__U_Element/ U_Element.pas
           |                     
           |__U_Exemples_Arbres/ U_Exemples_Arbres.pas
           |                     
           |__Questions/ Etude_d'un_arbre.pas 
                         recherche_d'arbre_extreme.pas
                         recherche_ABO.pas
                         construction_ABO.pas  
                         parcours_AB.pas

Pour les commentaires :

tarik.djebien@etudiant.univ-lille1.fr

Cordialement.
