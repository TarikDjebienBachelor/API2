README : 

// Auteur : Djebien Tarik
// Date   : novembre 2009
// Objet  : Les listes

Ci-Joint le TP numero 6 

Arborescence de l'archive Tarik_Djebien_MIMP32.tar.gz :
    |
    |_____README
    |
    |_____tp-liste1.pdf
    |
    |_____Les_listes/
           |
           |
           |__U_Liste/ U_Liste.[pas/o/ppu]
           |                     
           |__U_Element/ U_Element.[pas/o/ppu]
           |                     
           |__U_Exemples_Listes/ U_Exemples_Listes.[pas/o/ppu]
           |                     
           |__Questions/ Question[2-6].pas 
          

Pour les commentaires :

tarik.djebien@univ-lille1.fr

Cordialement.
