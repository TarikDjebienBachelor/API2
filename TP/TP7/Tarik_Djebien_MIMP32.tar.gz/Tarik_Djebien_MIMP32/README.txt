README : 

// Auteur : Djebien Tarik
// Date   : novembre 2009
// Objet  : Les listes II

Ci-Joint le TP numero 7 

Arborescence de l'archive Tarik_Djebien_MIMP32.tar.gz :
    |
    |_____README
    |
    |_____tp-liste2.pdf
    |
    |_____Les_listes_II/
           |
           |
           |__U_Liste/ U_Liste.pas
           |                     
           |__U_Element/ U_Element.pas
           |                     
           |__U_Exemples_Listes/ U_Exemples_Listes.pas
           |                     
           |__Questions/ Question[2-4-7-9-11-13].pas 
          

Pour les commentaires :

tarik.djebien@etudiant.univ-lille1.fr

Cordialement.
