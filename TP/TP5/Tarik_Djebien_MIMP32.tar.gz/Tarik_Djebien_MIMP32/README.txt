README : 

// Auteur : Djebien Tarik
// Date   : novembre 2009
// Objet  : Gestion dynamique de la mémoire

Ci-Joint le TP numero 5 

Arborescence de l'archive Tarik_Djebien_MIMP32.tar.gz :
    |
    |_____README
    |
    |_____tp-pointeur.pdf
    |
    |_____Gestion_dynamique_de_la_mémoire/
           |
           |
           |________Programmes_avec_pointeurs/
           |                     |__Adresse_de_variables/ Question1.pas
           |                     |
           |                     |__Allocation_dynamique_de_la_memoire/ Question5.pas
           |                     |
           |                     |__Arithmétique_sur_les_pointeurs/ Question[3-4].pas
           |                     |
           |                     |__Pointeur_vers_une_variable/ Question2.pas
           |                     |
           |                     |__tableaux_et_pointeurs/ Question[9-11].pas
           |                     |
           |                     |__Une_fonction_avec_des_pointeurs/ factorielle[2-4].pas
           |
           |__________Simulation_de_pointeurs/
                                            |__U_Pointeur/  U_Pointeur.pas
                                            |  
                                            |__Applications/ Question[19-22].pas

Pour les commentaires et les remarques voici mon mail:

tarik.djebien@univ-lille1.fr

merci,
Cordialement.
